// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

extern unsigned char tileset [0];
#asm
	._tileset
		BINARY "tileset.bin"
#endasm
